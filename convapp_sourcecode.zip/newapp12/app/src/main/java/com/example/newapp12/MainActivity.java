package com.example.newapp12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText miles = findViewById(R.id.editTextmiles);
                EditText km = findViewById(R.id.editTextkm);
                double vales =  Double.parseDouble(miles.getText().toString());
                double vkm = vales/0.62;
                DecimalFormat format1 = new DecimalFormat("##.##");
                km.setText(format1.format(vkm));




            }


        });
        Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText miles = findViewById(R.id.editTextmiles);
                EditText km = findViewById(R.id.editTextkm);
                double vkm =  Double.parseDouble(km.getText().toString());
                double vales = vkm *0.62;
                DecimalFormat format1 = new DecimalFormat("##.##");
                miles.setText(format1.format(vales));




            }


        });


    }
}
